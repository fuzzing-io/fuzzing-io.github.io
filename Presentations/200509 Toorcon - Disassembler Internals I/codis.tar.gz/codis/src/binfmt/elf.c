#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include "elf.h"
#include "dis.h"

int dt_load_elf_sections(binary_t *target, unsigned char *image);
int dt_load_elf_symbols(binary_t *target, unsigned char *image);

unsigned char * dt_elf_strtab_lookup(unsigned char *image, unsigned int shndx, unsigned int strndx);

binary_t * dt_load_elf_binary(unsigned char *path)
{
	binary_t *target;
	unsigned char *image;
	struct stat st;
	int fd;

	Elf32_Ehdr *Ehdr;

	
	if(stat(path, &st) < 0)
	{
		perror("[dt_load_elf_binary] could not stat file");
		return NULL;
	}
	
	if(st.st_size <= 0)
	{
		perror("[dt_load_elf_binary] supplied file size <= 0");
		return NULL;
	}
	
	fd = open(path, O_RDONLY);
	if(fd < 0)
	{
		perror("[dt_load_elf_binary] could not open binary");
		return NULL;
	}

	image = mmap(NULL, st.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
	if(!image)
	{
		perror("[dt_load_elf_binary] could not map file");
		return NULL;
	}

	if(*(unsigned int *)image != 0x464c457f)
	{
    		if(options.verbose >= OUTPUT_VERBOSITY_DEBUG)
		    vlog("[dt_load_elf_binary] file is not a valid ELF file\n");

		return NULL;
	}

	Ehdr = (Elf32_Ehdr *)image; 	
	
	/* perform ehdr sanity checks */
	if((Ehdr->e_phoff + (Ehdr->e_phnum * sizeof(Elf32_Phdr))) > st.st_size
	|| (Ehdr->e_phoff + (Ehdr->e_phnum * Ehdr->e_phentsize)) > st.st_size
	|| (Ehdr->e_shoff + (Ehdr->e_shnum * sizeof(Elf32_Shdr))) > st.st_size
	|| (Ehdr->e_shoff + (Ehdr->e_shnum * Ehdr->e_shentsize)) > st.st_size
	|| (Ehdr->e_ehsize > sizeof(Elf64_Ehdr))
	|| (Ehdr->e_shstrndx > Ehdr->e_shnum))
	{
		vlog("[dt_load_elf_binary] Corrupt ELF header values detected\n");
		return NULL;
	}
	
	target = calloc(1, sizeof(binary_t));
	if(!target)
		return NULL;

	if(options.verbose >= OUTPUT_VERBOSITY_DEBUG)
	    vlog("Parsing ELF Header\n");

	strncpy(target->name, path, sizeof(target->name));
	target->size = st.st_size;

	target->type = BINARY_FORMAT_ELF;
	target->entry = Ehdr->e_entry;
	target->entry_offset = 0; /* fill during section parsing */
		
	switch(Ehdr->e_ident[EI_CLASS])
	{
		case 2:
			target->wordsz = 64;
			break;
		case 1:
			target->wordsz = 32;
			break;
		default:
			vlog("[dt_load_elf_binary] warning: Invalid ELF CLASS, defaulting to 32-bit\n");
			target->wordsz = 32;
			break;
	}
	switch(Ehdr->e_ident[EI_DATA])
	{
		case ELFDATA2MSB: 
			target->endian = BINARY_ENDIAN_BIG;
			break;
		case ELFDATA2LSB: 
			target->endian = BINARY_ENDIAN_LITTLE;
			break;
		default:
			vlog("[dt_load_elf_binary] warning: Invalid ELF DATA, defaulting to Little Endian\n");
			target->endian = BINARY_ENDIAN_LITTLE;
			break;
	}
	switch(Ehdr->e_machine)
	{
		case EM_386:
			target->arch = BINARY_ARCH_IA32;
			break;
	}

	if(dt_load_elf_sections(target, image) < 0)
	{
		vlog("[dt_load_elf_binary] error: could not load elf sections\n");
		return NULL;
	}
	
	target->sym_idx = splay_init();
	if(dt_load_elf_symbols(target, image) < 0)
		vlog("[dt_load_elf_binary] warning: could not load elf symbols\n");
		

	if(munmap(image, st.st_size) < 0)
	{
		perror("[dt_load_elf_binary] warning: could not unmap binary image");
	}
	return target;
}	


unsigned char * dt_elf_strtab_lookup(unsigned char *image, unsigned int shndx, unsigned int strndx)
{
	Elf32_Ehdr *Ehdr = (Elf32_Ehdr *)image;
	Elf32_Shdr *strtab;

	void *va = NULL; 

	if(shndx == 0)
	{
		return NULL;
	}
	
	strtab = (Elf32_Shdr *)(image + Ehdr->e_shoff + (shndx * Ehdr->e_shentsize));
	if(strtab->sh_type != SHT_STRTAB)
	{
		vlog("[dt_elf_strtab_lookup] warning: invalid section requested\n");
		return NULL;
	}
	
	return image + strtab->sh_offset + strndx; 
	
}


int dt_load_elf_sections(binary_t * target, unsigned char *image)
{
	int i;
	
	section_t *sections = NULL;
	section_t *shdr_p = sections;

	Elf32_Ehdr *Ehdr = (Elf32_Ehdr *)image; 
	Elf32_Shdr *Shdr = NULL; 
	
	if(options.verbose)
		vlog("[dt_load_elf_sections] Loading Sections\n");
		
	if(Ehdr->e_shnum == 0)
	{
		vlog("[dt_load_elf_sections] error: No sections are present\n");
		return -1;
	}
	else
	{
		Shdr = (Elf32_Shdr *)(image + Ehdr->e_shoff);
	}

	for(i = 0; i < Ehdr->e_shnum; i++, Shdr++)
	{
		section_t *section = NULL;
	
		if((Ehdr->e_shoff > target->size)
		|| (Ehdr->e_shoff + (i * Ehdr->e_shentsize) != Shdr->sh_offset)
		|| (Ehdr->e_shoff + (i * Ehdr->e_shentsize) + Shdr->sh_size > target->size)
		|| (Ehdr->e_shoff + (Ehdr->e_shstrndx * Ehdr->e_shentsize) + Shdr->sh_name > target->size)
		|| (Shdr->sh_link > Ehdr->e_shnum)
		|| (Shdr->sh_info > Ehdr->e_shnum)
		|| (Shdr->sh_entsize > Shdr->sh_size))
		{
			vlog("[dt_load_elf_sections] error: section information is corrupt (shnum: %d)\n", i);
			vlog("%d\n", (int)Shdr - (int)image);

			return -1;
		}
		
		if(!(section = calloc(sizeof(section_t), 1)))
		{
			 vlog("[dt_load_elf_sections] error: could not allocate memory\n");
			 return -1;
		}
		
		section->va = Shdr->sh_addr;
		section->offset = Shdr->sh_offset;
		section->size = Shdr->sh_size;

		/* determine section type */
		if(Shdr->sh_flags & SHF_ALLOC)
		    section->type |= BINARY_SCN_TYPE_LOAD;

		if(Shdr->sh_flags & SHF_EXECINSTR)
		    section->type |= BINARY_SCN_TYPE_CODE;
		else
		    section->type |= BINARY_SCN_TYPE_DATA;

		/* determine section perms */
		section->perm = PERM_READ;

		if(Shdr->sh_flags & SHF_WRITE)
		    section->perm |= PERM_WRITE;

		if(Shdr->sh_flags & SHF_EXECINSTR)
		    section->perm |= PERM_EXEC;

		if(((Ehdr->e_shstrndx * Ehdr->e_shentsize) + Shdr->sh_name) > target->size)
		{
			vlog("[dt_load_elf_sections] error: strtab information is corrupt\n", section->name);
			return -1;
		}

		section->name = dt_elf_strtab_lookup(image, Ehdr->e_shstrndx, Shdr->sh_name);
		if(section->name > (image + target->size))
		{
			vlog("[dt_load_elf_sections] error: strtab information is corrupt (illegal reference: %p)\n", section->name);
			return -1;
		}

		if(section->name)
		{
			/* create local copy of section name */
			section->name = strdup(section->name);
		}
		section->next = NULL;

		if(shdr_p == NULL)
		{
			section->prev = NULL;
			shdr_p = sections = section;
		}
		else
		{
			section->prev = shdr_p;
			shdr_p->next = section;
			shdr_p = shdr_p->next;
		}
	}

	target->sections = sections;
	
	return 0;
}

int dt_load_elf_dynamic(unsigned char *image)
{
	return -1;
}

int dt_load_elf_symbols(binary_t * target, unsigned char *image)
{
	symbol_t *symbols = NULL;
	symbol_t *sym_p = symbols; 

	Elf32_Ehdr *Ehdr = (Elf32_Ehdr *)image;
	Elf32_Shdr *Shdr = (Elf32_Shdr *)(image + Ehdr->e_shoff);

	unsigned int i,j;
	
	for(i = 0; i < Ehdr->e_shnum; i++, Shdr++)
	{
		if(Shdr->sh_type == SHT_SYMTAB || Shdr->sh_type == SHT_DYNSYM)
		{
			Elf32_Sym *Sym = (Elf32_Sym *)(image + Shdr->sh_offset);

			
			
			for(j = 0; j < Shdr->sh_size / Shdr->sh_entsize; j++, Sym++)
			{
				symbol_t *symbol = NULL;
				
				if((Ehdr->e_shoff + (Shdr->sh_link * Ehdr->e_shentsize) + Sym->st_name > target->size)
				|| (Sym->st_size > Shdr->sh_entsize)
				|| (Sym->st_shndx > Ehdr->e_shnum))
				{
					vlog("[dt_load_elf_symbols] error: symbol information is corrupt \n");
					return -1;
				}
				
				symbol = calloc(1, sizeof(symbol_t));
				if(!symbol)
				{
					vlog("[dt_load_elf_symbols] error: allocation failed\n");
					return -1;
				}
				symbol->va = Sym->st_value;
				symbol->offset = 0;
				symbol->size = Sym->st_size;
				symbol->type = ELF32_ST_TYPE(Sym->st_info);
				symbol->name = dt_elf_strtab_lookup(image, Shdr->sh_link, Sym->st_name);
				if(symbol->name > (image + target->size))
				{
					vlog("[dt_load_elf_symbols] error: allocation failed\n");
					return -1;
				}
				

				/* create local copy of symbol name */
				if(symbol->name)
					symbol->name = strdup(symbol->name);
				
				if(sym_p == NULL)
				{
					symbol->prev = NULL;
					sym_p = symbols = symbol;
				}
				else
				{
					symbol->prev = sym_p;
					sym_p->next = symbol;
					sym_p = sym_p->next;
				}
				splay_insert(&target->sym_idx, (void *)symbol->va, symbol, splay_by_addr);
				
			}
		}
	}			

	target->symbols = symbols;
	return 0;
}
