typedef struct _stree
{
	struct _stree *left;
	struct _stree *right;
	int inode;
	//unsigned char md5[16];
	unsigned char md5[20];
	unsigned char fname[4096];
} stree;

stree *splay (int inode, stree * tree);
stree *insert (int inode, char *md5, char *fname, stree * tree);
