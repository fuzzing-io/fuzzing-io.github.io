/*
** md5verify userland daemon 
** rjohnson@uninformed.org
**
** This is the userland portion of md5verify. The daemon polls
** the md5verify device waiting for a lookup request to be sent.
** The lookup request is sent in the following format:
** [device][inode][filename]
** 
** The daemon looks up the associated hash which is stored in a 
** splay tree keyed off of the inode. The daemon then sends the 
** appropriate hash back to the driver through the device file.
**
** Updated to use SHA and LSM by Rodrigo Rubira Branco <rodrigo@kernelhacking.com>
*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/poll.h>
#include <errno.h>
#include <sys/select.h>
#include <sys/time.h>
#include <sys/types.h>
#include <linux/limits.h>
#include <elf.h>

#ifndef USE_SHA
 #include "md5.h"
#else
 #include "sha1.h"
#endif

#include "splay.h"


void
usage (char *name)
{
  printf ("usage: %s [options]\n", name);
  printf ("  -f [file list]\n");
  printf ("\n");
  exit (0);
}

#ifdef USE_SHA
int
sha1sum (unsigned char *hash, char *filename, int size)
{
  unsigned char *buf;
  ssize_t ret;
  int fd;
  SHA1_CTX ctx;

  fd = open (filename, O_RDONLY);
  if (fd < 0)
  {
    perror ("open");
    return -1;
  }
  memset (hash, 0, sizeof (hash));
  buf = malloc (size);
  if (buf <= 0)
  {
    perror ("malloc");
    return -1;
  }
  ret = read (fd, buf, size);
  if (ret < 0)
    goto cleanup;

  SHA1Init (&ctx);
  SHA1Update (&ctx, buf, size);
  SHA1Final (hash, &ctx);

cleanup:
  free (buf);
  return ret;
}

#else

int
md5sum (unsigned char *hash, char *filename, int size)
{
  unsigned char *buf;
  ssize_t ret;
  int fd;
  md5_context ctx;

  fd = open (filename, O_RDONLY);
  if (fd < 0)
  {
    perror ("open");
    return -1;
  }
  memset (hash, 0, sizeof (hash));
  buf = malloc (size);
  if (buf <= 0)
  {
    perror ("malloc");
    return -1;
  }
  ret = read (fd, buf, size);
  if (ret < 0)
    goto cleanup;
  md5_starts (&ctx);
  md5_update (&ctx, buf, size);
  md5_finish (&ctx, hash);

cleanup:
  free (buf);
  return ret;
}
#endif

int
load_files (char *list, stree ** devices)
{
  #ifndef USE_SHA
   char hash[16];
  #else
   char hash[20];
  #endif

  char filename[PATH_MAX];
  struct stat st;
  FILE *fd;
  ushort index;
  int i, fcount=0;

  fd = fopen (list, "r");
  if (fd < 0)
  {
    perror ("open");
    return -1;
  }

  printf ("loading db ..\n");
  memset (filename, 0, sizeof (filename));
  while (fgets (filename, sizeof (filename) - 1, fd))
  {
    fcount++;
    filename[strlen (filename) - 1] = 0;	// get rid of trailing '\n'
    if (lstat (filename, &st) < 0)
    {
      perror ("lstat");
      return -1;
    }
    #ifndef USE_SHA
    if (md5sum ((unsigned char *) &hash, filename, st.st_size) < 0)
    #else
    if (sha1sum ((unsigned char *) &hash, filename, st.st_size) < 0)
    #endif
    {
      printf ("md5sum failed\n");
      return -1;
    }

    index = major (st.st_dev) * 256 + minor (st.st_dev);
    devices[index] = insert (st.st_ino, hash, filename, devices[index]);
    if (devices[index] == NULL)
      return -1;

    printf ("%04x  %08d  ", index, (int) st.st_ino);
    #ifndef USE_SHA
    for (i = 0; i < 16; i++)
    #else
    for (i = 0; i < 20; i++)
    #endif
    {
      printf ("%02x", hash[i]);
    }
    printf ("  %s\n", filename);

  }
  printf ("-- database loaded with %d files --\n\n", fcount);

  return 0;
}

int
main (int argc, char **argv)
{
  unsigned char buf[PATH_MAX + 8 + 4];	// device + inode + path
  fd_set fds;
  struct timeval tv;
  int c, i, dev;
  stree **devices;
  unsigned short index;
  unsigned long inode;

  if (argc < 2)
    usage (argv[0]);

  if (getuid () != 0)
  {
    printf ("Sorry, root privleges are required for this daemon.\n");
    exit (0);
  }

  while ((c = getopt (argc, argv, "f:")) != -1)
  {
    switch (c)
    {
    case 'f':
      devices = (stree **) malloc (sizeof (unsigned long) * 65536);
      memset (devices, 0, sizeof (unsigned long) * 65536);
      if (load_files (optarg, devices) < 0)
	goto cleanup;
      break;
    default:
      usage (argv[0]);
    }
  }

// poll the md5verify device 
  dev = open ("/dev/md5verify", O_RDWR);
  if (dev < 0)
  {
    perror ("open");
    exit (0);
  }

  while (1)
  {
    FD_ZERO (&fds);
    FD_SET (dev, &fds);
    tv.tv_sec = 1;
    tv.tv_usec = 0;

    if (select (dev + 1, &fds, NULL, NULL, &tv) < 0)
    {
      perror ("select");
      goto cleanup;
    }

    if (FD_ISSET (dev, &fds))
    {
      memset (buf, 0, sizeof (buf));
      read (dev, buf, sizeof (buf));
      memcpy ((unsigned short *) &index, (char *) &buf, sizeof (index));
      memcpy ((unsigned int *) &inode, (char *) &buf + 2, sizeof (inode));
      devices[index] = splay (inode, devices[index]);

      #ifndef USE_SHA
      for (i = 0; i < 16; i++)
      #else
      for (i = 0; i < 20; i++)
      #endif
      {
	printf ("%02x", devices[index]->md5[i]);
      }
      printf ("  %s\n", devices[index]->fname);

      if (devices[index]->md5 != NULL)
        #ifndef USE_SHA
	write (dev, devices[index]->md5, 16);
   	#else
	write (dev, devices[index]->md5, 20);
	#endif
      else
      {
	i = -1;
	write (dev, (char *) i, 1);
      }
    }
  }

cleanup:
  if (dev)
    close (dev);
  free (devices);
  return 0;
}
