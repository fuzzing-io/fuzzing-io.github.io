#ifndef __LISTS_H
#define __LISTS_H

typedef struct splay_s {
	struct splay_s	*left;
	struct splay_s	*right;
	void		*key;
	void 		*data;
} splay_t;

extern splay_t *splay_init(void);
extern void *splay_find(splay_t **tree, void *key,
	int (*key_cmp)(void *, void *));
extern int splay_insert(splay_t **tree, void *key, void *data,
	int (*key_cmp)(void *, void *));
extern splay_t *splay_delete(splay_t **tree, void *key,
	int (*key_cmp)(void *, void *));

typedef struct ll_node {
	struct ll_node *next;
	void *data;
} list_t;


int splay_by_addr(void *s1, void *s2);
int splay_by_name(void *s1, void *s2);



#endif /* __LISTS_H */
