#include <unistd.h>
#include <sys/stat.h>
#include "dis.h"
#include "libdasm.h"


xref_t * add_xref(binary_t *target, int va, int refaddr, unsigned short perm)
{
    xref_t * xref;

    xref = calloc(1, sizeof(xref_t));
    if(!xref)
	return NULL;

    xref->from = va;
    xref->perm = perm;
    xref->to   = refaddr;

    
    /* add xref to list */
    if(target->xrefs) 
    {
        target->xrefs->prev = xref;
        xref->next = target->xrefs; 
    }
    target->xrefs = xref; 

    /* add xref to splay tree indexed by referenced addr */
    splay_insert(&target->xref_idx, (void *)xref->to, xref, splay_by_addr);

    return xref; 
}

func_t * add_func(binary_t *target, int va, int offset, name_t *name)
{
    func_t *func;

    func = calloc(1, sizeof(func_t));
    if(!func) 
	return NULL;

    func->va = va; 
    func->offset = offset;
    func->name = name;

    if(target->functions)
    {
        target->functions->prev = func;
        func->next = target->functions;
    }
    target->functions = func;

    splay_insert(&target->func_idx, (void *)func->va, func, splay_by_addr);
    
    return func;
}

name_t * add_name(binary_t *target, int va, int refaddr, enum Instruction type)
{
    name_t * name; 

    name = calloc(1, sizeof(name_t));
    if(!name)
	return NULL;

    if(type == INSTRUCTION_TYPE_JMP || type == INSTRUCTION_TYPE_JMPC)
    {   		    	
        	name->va = refaddr;
    		name->type = DB_NAME_TYPE_LOC;    		
    		name->data = calloc(1, 13);
    		snprintf(name->data, 13, "loc_%08x", refaddr);
    }
    else if(type == INSTRUCTION_TYPE_CALL)
    {
		symbol_t *sym = NULL;
    	
        	name->va = refaddr;
        	name->type = DB_NAME_TYPE_SUB;

		if(target->sym_idx)
			sym = splay_find(&target->sym_idx, (void *)refaddr, splay_by_addr);

		if(sym)
			name->data = sym->name;
		else
		{
			name->data = calloc(1, 13);
			snprintf(name->data, 13, "sub_%08x", refaddr);
		}
    }
    else if(type == INSTRUCTION_TYPE_INT)
    {
        name->va = refaddr;
    	name->type = DB_NAME_TYPE_INT;
    	name->data = calloc(1, 13);
    	snprintf(name->data, 13, "int_%08x", refaddr);
    }
    else
    {
        name->va = refaddr;
    	name->type = DB_NAME_TYPE_DATA;
    	snprintf(name->data, 16, "data_%08x:", refaddr);
    }

    if(target->names)
    {
        target->names->prev = name;
        name->next = target->names;
    }
    target->names = name;

    splay_insert(&target->name_idx, (void *)refaddr, name, splay_by_addr);

    return name;

}


int analyze_xref_op(binary_t *target, INSTRUCTION *inst, insn_t *insn, OPERAND *op)
{
    int ret = 0;
    int refaddr = 0;

    if(!op)
	return 0;

    if(op->type == OPERAND_TYPE_IMMEDIATE)
    {
    	if(MASK_AM(op->flags) == AM_J) // immediate value relative to eip 
    	{
		name_t * name;

		refaddr = op->immediate + inst->length + insn->va;
    
    	    add_xref(target, insn->va, refaddr, MASK_PERMS(op->flags));
    
    	    /* create symbolic name entry */
         name = add_name(target, insn->va, refaddr, inst->type);
    	    if(name)
    	    {     
        		if(inst->type == INSTRUCTION_TYPE_CALL)
        		{
        		    add_func(target, insn->va, insn->offset, name);
        		}
    	    }
    	}
    }

    return ret;
}



int analyze_xrefs(binary_t *target, insn_t * insn, INSTRUCTION *inst)
{
    int ret = 0; 

    if(analyze_xref_op(target, inst, insn, &inst->op2))
	ret++;

    if(analyze_xref_op(target, inst, insn, &inst->op1))
	ret++;

    if(analyze_xref_op(target, inst, insn, &inst->op3))
	ret++;

   
   return ret;
}

int dt_disas_x86_binary(binary_t *target, unsigned char *bin)
{
    unsigned char *data;
    int insn_len;
    INSTRUCTION inst;	// instruction struct from libdasm
    insn_t *insn;	// instruction struct 

    section_t * sect_p = target->sections;

    while(sect_p)
    {
	int offset = 0;
	section_t *section = sect_p;
	insn_t * insn_p, *insns;

	insn_p = insns = section->insns; 
	if(insns)
	{
	    while(insns->next)
		insn_p = insns->next;
	}


	if(!(section->perm & BINARY_SCN_TYPE_CODE))
	{	
	    sect_p = sect_p->next;
	    continue;
	}

	data = bin + section->offset;

	vlog("Disassembling Section %s\n", section->name);

	while(offset < section->size)
	{
	    insn_len = get_instruction(&inst, data + offset, MODE_32);

	    // INVALID INSTRUCTION -- FIXME -- we lose these bytes
	    if (!insn_len || (insn_len + offset > section->size)) {
		offset++;
		continue;
	    }

	    insn = calloc(1, sizeof(insn_t));
	    insn->va     = section->va + offset;		// Virtual Address
	    insn->offset = section->offset + offset;		// File offset
	    insn->size   = inst.length;		       		// Size of insn
	    //insn->type   = inst.type;	 			// Type of insn
	    if(inst.type == INSTRUCTION_TYPE_CALL)
	    		insn->type = DB_INSN_TYPE_CALL;	    		
	    else if(inst.type == INSTRUCTION_TYPE_JMP)
	    		insn->type = DB_INSN_TYPE_JMP;	    		
	    		
	   
	    memcpy(insn->bytes, data + offset, inst.length);

	    get_mnemonic_string(&inst, options.asm_fmt, insn->mnemonic, sizeof(insn->mnemonic));

	    get_operand_string(&inst, &inst.op2, options.asm_fmt, section->va + offset, insn->src, sizeof(insn->src));
	    insn->stype = inst.op2.type;
	    insn->s_perm = MASK_PERMS(inst.op2.flags);

	    get_operand_string(&inst, &inst.op1, options.asm_fmt, section->va + offset, insn->dest, sizeof(insn->dest));
	    insn->dtype = inst.op1.type;
	    insn->d_perm = MASK_PERMS(inst.op1.flags);

	    get_operand_string(&inst, &inst.op3, options.asm_fmt, section->va + offset, insn->aux, sizeof(insn->aux));
	    insn->atype = inst.op3.type;
	    insn->a_perm = MASK_PERMS(inst.op3.flags);

	    insn->name = NULL;		// Address name

	    /* add insn to lists */
	    splay_insert(&target->insn_idx, (void *)insn->va, insn, splay_by_addr);

	    if(insn_p == NULL)
		    insn_p = insns = insn;
	    else
	    {
		    insn->prev = insn_p;
		    insn_p->next = insn;
		    insn_p = insn_p->next;
	    }

	    analyze_xrefs(target, insn, &inst);
            

	    offset += insn_len;
	}
	sect_p->insns = insns; 
	sect_p = sect_p->next;
    }

    return 0;
}








