
codis -- simple console disassembler
=======================================
Richard Johnson <rjohnson@idefense.com>


1. Introduction
===============

codis is a console-based disassembler written for the purpose of demonstrating
the basics of disassembly analyzer programming. This software was released as
example code accompanying the information provided in the Toorcon 7
presentation titled "Disassembler Internals".  codis is written in C and will
compile on Linux and Win32 systems with a cygwin environment. 

codis currently offers the following features: 

  - Instruction decoding
    - ia32 

  - Binary format handling 
    - PECOFF
    - ELF

  - Disassembly analysis 
    - Function detection 
    - Code cross-references 

codis can easily be extended to support more binary formats and 
processor architectures. 


2. Building
===========

The Makefile included should build codis on Linux, BSD, and Windows systems
(with cygwin). codis requires libdasm 1.3 or later for x86 instruction support.
The source for libdasm 1.3.1 is included in /lib and should be built before
trying to compile codis. 


3. Usage
========

codis is very simple to use. codis will automatically determine the binary
format of the supplied file and begin binfmt parsing and disassembly. codis
will hexdump binary sections which are marked as data and will automatically
disassemble code sections. codis can output symbol information, strings, and
disassembly code. 


4. Credits 
==========

The author would like to thank Jarkko Turkulainen (jt@nologin.org) for
developing and supporting the excellent x86 disassembler package libdasm that
is included with this source code. 


5. License 
==========

This software is available under the GNU Public License Version 2 (GPLv2).
Please read LICENSE.txt for more information regarding licensing. 


