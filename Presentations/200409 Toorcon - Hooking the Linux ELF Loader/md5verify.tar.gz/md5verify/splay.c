#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "splay.h"

stree *
splay (int inode, stree * tree)
{
  stree n, *left, *right, *tmp;
  if (!tree)
    return NULL;
  n.left = n.right = NULL;
  left = right = &n;
  for (;;)
  {
    if (inode < tree->inode)
    {
      if (tree->left == NULL)
	break;
      if (inode < tree->left->inode)
      {
	tmp = tree->left;
	tree->left = tmp->right;
	tmp->right = tree;
	tree = tmp;
	if (tree->left == NULL)
	  break;
      }
      right->left = tree;
      right = tree;
      tree = tree->left;
    }
    else if (inode > tree->inode)
    {
      if (tree->right == NULL)
	break;
      if (inode > tree->right->inode)
      {
	tmp = tree->right;
	tree->right = tmp->left;
	tmp->left = tree;
	tree = tmp;
	if (tree->right == NULL)
	  break;
      }
      left->right = tree;
      left = tree;
      tree = tree->right;
    }
    else
    {				// found the leaf we're looking for.
      break;
    }
  }

  left->right = tree->left;
  right->left = tree->right;
  tree->left = n.right;
  tree->right = n.left;
  return tree;
}

stree *
insert (int inode, char *md5, char *fname, stree * tree)
{
  stree *new;
  new = (stree *) malloc (sizeof (stree));
  if (!new)
  {
    perror ("malloc");
    return NULL;
  }

  new->inode = inode;
  memset (new->md5, 0, sizeof (new->md5));
  //memcpy (new->md5, md5, 16);
  memcpy (new->md5, md5, 20);
  memset (new->fname, 0, sizeof (new->fname));
  strncpy ((char *) new->fname, fname, strlen (fname));

  // the leaf we're adding is the first one. initialize it's left and right
  // pointers and return the allocated leaf as the head of the tree.
  if (tree == NULL)
  {
    new->left = new->right = NULL;
    return new;
  }
  tree = splay (inode, tree);
  if (inode < tree->inode)
  {
    new->left = tree->left;
    new->right = tree;
    tree->left = NULL;
    return new;
  }
  else if (inode > tree->inode)
  {
    new->right = tree->right;
    new->left = tree;
    tree->right = NULL;
    return new;
  }
  else
  {
    free (new);
    return tree;
  }
}
