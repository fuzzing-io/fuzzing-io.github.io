#include "dis.h"


int dt_hexdump(unsigned char *buf, int len, unsigned long va)
{
	int i, j;

	for (i = 0; i < len; i += 16) 
	{
		vlog("\n%08x |  ", va + i);
		
		for (j = 0; j < 16; j++)
		{
			if ( i+j < len ) 
				vlog("%02X ", buf[i+j]);
			else
				vlog("   ");
	
		}

		vlog(" | ");
		
		for (j = 0; j < 16; j++)
		{
			unsigned char ch = (i+j < len) ? buf[i+j] : ' ';
			if ((ch < 0x20) || (ch > 0x7e)) 
				ch = '.';
			vlog("%c", ch);
		}
	}
	return len;
}



