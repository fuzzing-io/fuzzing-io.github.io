#!/bin/sh

cvs -d:pserver:anonymous@cvs.sourceforge.net:/cvsroot/ida-x86emu login 
cvs -z3 -d:pserver:anonymous@cvs.sourceforge.net:/cvsroot/ida-x86emu co -P ida-x86emu
