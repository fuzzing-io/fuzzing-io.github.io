#include "dis.h"


int dt_disas_analyze_wrappers(binary_t *target);


int dt_disas_analyzer(binary_t *target)
{




	dt_disas_analyze_wrappers(target);


	return 0;
}


int dt_disas_analyze_wrappers(binary_t *target)
{
	name_t *name = target->names;

	while(name)
	{
		insn_t *f_insn = NULL; 	
		
		if(name->type == DB_NAME_TYPE_SUB)
		{			
			f_insn = splay_find(&target->insn_idx, (void *)name->va, splay_by_addr);
			
			if(f_insn && f_insn->type == DB_INSN_TYPE_JMP)
			{
				symbol_t *w_name;
				char *new_name;
				
				w_name = splay_find(&target->sym_idx, (void *)strtoul(&f_insn->dest[1], NULL, 16), splay_by_addr);
				if(w_name)
				{
					new_name = calloc(1, strlen(name->data) + 1 + sizeof("wrapper_"));
					sprintf(new_name, "wrapper_%s", w_name->name);
					free(name->data);
					name->data = new_name;
				}

			}
			
		}		
		name = name->next;
	}	
	
	return 0;	
}

