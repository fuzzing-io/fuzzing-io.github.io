#include <unistd.h>
#include "dis.h"

static void usage(char *argv)
{
	printf(
		"Usage: %s [OPTIONS] [file path]\n"
		"\n"
		"Display Options\n"
		"  -f <format>     disassembly format [att | intel]\n"
		"  -b              show hexbytes with disassembly\n"
		"  -s              dump symbol listing\n"
		"  -h              only show headers\n"
		"  -v              verbosity (use multiple times)\n"
		"\n"
		"Output Options\n"
		"  -o <filename>   write output to file\n"
		, argv);
	exit(0);
}

int main(int argc, char **argv)
{
	binary_t *target = NULL;
	char *path;
	int  c;

	// check args
	if(argc < 2)
		usage(argv[0]);

	disasm_init();
	binfmt_init();

	while((c = getopt(argc, argv, "Dvbf:sSho:")) != -1)
	{
		switch(c)
		{
		    case 'v':
			options.verbose++;
			break;
		    case 'D':
			options.verbose = OUTPUT_VERBOSITY_DEBUG;
		    case 'b':
			options.showbytes++;
			break;
		    case 's':
			options.showsyms++;
			break;
		    case 'S':
			options.showstrings++;
			break;
		    case 'h':
			options.headers++;
			break;
		    case 'f':
			if(!strcmp(optarg, "intel"))
				options.asm_fmt = FORMAT_INTEL;
			else if(!strcmp(optarg, "att"))
				options.asm_fmt = FORMAT_ATT;
			else
			{
				printf("error: disassembly format \"%s\" is not supported\n", optarg);
				usage(argv[0]);
			}
			break;	
   		    case 'o':
			options.logfile = fopen(optarg, "w+");
			if(!options.logfile)
			{
				perror("fopen");
				usage(argv[0]);
			}
			break;

		    default:
			usage(argv[0]);
		}
	}

    //options.showbytes = 1;
	
	path = strdup(argv[optind]);

	// create target instance
	vlog("Loading Binary: %s\n", path);
	target = dt_load_binary(path);
	if(!target)
	{
		vlog("Error loading binary. Exiting .. \n");
		exit(1);
	}


	if(!options.headers)
	{
		// disassemble binary 
		vlog("Disassembling Binary..\n");

		if(dt_disas_binary(target) < 0)
		{
			vlog("Error disassembly binary. Exiting .. \n");
			return -1;
		}
	}
	dt_show_file_header(target);
	dt_show_disassembly(target);
	if(options.showsyms)
		dt_show_symbols(target);
	
	return 0;
}

