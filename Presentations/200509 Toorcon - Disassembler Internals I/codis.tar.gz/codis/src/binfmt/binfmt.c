#include "dis.h"


int register_binfmt(struct binfmt *new)
{
	struct binfmt *ptr;

	if(!new)
		return -1;
	
	if(binfmts == NULL)
	{
		binfmts = new;
	}
	else 
	{
		ptr = (struct binfmt *)&binfmts;
		while(ptr->next)
			ptr = ptr->next;

		ptr->next = new;
	}			
	return 0;
}

static struct binfmt elf = {
	.binfmt = BINARY_FORMAT_ELF,
	.load_binary = dt_load_elf_binary
};

static struct binfmt pe = {
	.binfmt = BINARY_FORMAT_PE,
	.load_binary = dt_load_pe_binary
};

int binfmt_init()
{
/*
	struct binfmt *elf = calloc(1, sizeof(struct binfmt));
	struct binfmt *pe = calloc(1, sizeof(struct binfmt));
	
	elf->binfmt = BINARY_FORMAT_ELF;	
	elf->load_binary = dt_load_elf_binary;

	pe->binfmt = BINARY_FORMAT_PE;
	pe->load_binary = dt_load_pe_binary;
*/
	if(register_binfmt(&pe) < 0)
		return -1;

	if(register_binfmt(&elf) < 0)
		return -1;


	return 0;
}

binary_t * dt_load_binary(unsigned char *path)
{
	struct binfmt *fmt; 
	binary_t * bin;

	for(fmt	= binfmts; fmt; fmt = fmt->next)
	{
		binary_t * (*load_binary)(unsigned char *path);
       		load_binary = fmt->load_binary;
		if(!load_binary)
			continue;
		
		bin = load_binary(path);
		if(bin)
			return bin;
	}

	return NULL;
}	

void dt_show_symbols(binary_t *target)
{
	symbol_t *sym; 

	vlog("\n"
           ";------------------------------------------------------------------------------\n"
           "; Displaying Symbols for %s\n"
           ";------------------------------------------------------------------------------\n\n",
           target->name);

	for(sym = target->symbols; sym; sym = sym->next)
	{
		vlog("0x%08x\t%d\t%s\n", sym->va, sym->size, sym->name);
	}	
}

int dt_show_file_header(binary_t *target)
{
	vlog("\n;------------------------------------------------------------------------------\n");
	vlog("; File Header\n");
	vlog(";------------------------------------------------------------------------------\n");
	vlog("; Binary format: %s %s \n", 
			target->wordsz == 32 ? "32-bit" : "64-bit",
			target->type == BINARY_FORMAT_ELF ? "ELF" : "PE");
	vlog("; Byte Ordering: %s\n",
			target->endian == BINARY_ENDIAN_LITTLE ? "Little Endian" : "Big Endian");
	vlog("; Entry Point:   %p\n", target->entry);
	vlog("; File Size:     %d bytes\n", target->size);
	vlog(";------------------------------------------------------------------------------\n");

	return 0;
}
