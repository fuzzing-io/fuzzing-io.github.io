#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include "lists.h"

/*
** linked list functions
*/ 

int list_push (list_t **node, void *data)
{
	list_t *new = (list_t *)malloc(sizeof(list_t));
	if(new == NULL)
		return -1;
	
	new->data = data;
	new->next = *node;
	*node = new;
	
	return 0;
}

int list_append (list_t **node, void *data)
{
	list_t *curr = *node;
	list_t *new = malloc(sizeof(list_t));
	
	if(new == NULL)
		return -1;
	
	new->data = data;
	new->next = NULL;
	
	if(curr == NULL)
	{
		*node = new;
		return 0;
	}
	
	while(curr->next != NULL)
		curr = curr->next;
	
	curr->next = new;
	return 0;
}

list_t *list_pop(list_t **node)
{
	list_t *old;
	void *data;
	
	old = (*node); 
	data = (*node)->data;
	*node = (*node)->next;
	free(old);
	return data;
}



/*
** splay tree functions
*/ 

static splay_t *null_node = NULL;

splay_t *splay_init(void)
{
	if(null_node == NULL)
	{
		null_node = (splay_t *) malloc(sizeof(splay_t));
		if(null_node == NULL)
			return NULL;
		memset(null_node, 0, sizeof(splay_t));
		null_node->left = null_node->right = null_node;
	}
	return null_node;
}

static splay_t *single_rotate_left(splay_t *x)
{
	splay_t *y;

	y = x->left;
	x->left = y->right;
	y->right = x;
	return y;
}

static splay_t *single_rotate_right(splay_t *x)
{
	splay_t *y;

	y = x->right;
	x->right = y->left;
	y->left = x;
	return y;
}

splay_t *splay(splay_t *x, void *key, int (*key_cmp)(void *, void *))
{
	splay_t header;
	splay_t *left_max, *right_min;

	header.left = header.right = null_node;
	left_max = right_min = &header;

	null_node->key = key;

	for(;;)
	{
		switch(key_cmp(x->key, key))
		{
			case -1: /* x->key < key */
				if(key_cmp(x->right->key, key) == -1)
					x = single_rotate_right(x);
				if(x->right == null_node)
					goto found;
				left_max->right = x;
				left_max = x;
				x = x->right;
				break;
			case  0: /* x->key == key */
				goto found;
				break;
			case  1: /* x->key > key */
				if(key_cmp(x->left->key, key) == 1)
					x = single_rotate_left(x);
				if(x->left == null_node)
					goto found;
				right_min->left = x;
				right_min = x;
				x = x->left;
				break;
		}
	}
found:
	left_max->right = x->left;
	right_min->left = x->right;
	x->left = header.right;
	x->right = header.left;
	return x;
}

void *splay_find(splay_t **tree, void *key, int (*key_cmp)(void *, void *))
{
	*tree = splay(*tree, key, key_cmp);
	if(key_cmp((*tree)->key, key) == 0)
		return (*tree)->data;
	return NULL;
}

int splay_insert(splay_t **tree, void *key, void *data, int (*key_cmp)(void *, void *))
{
	splay_t *t, *new;
	
	t = *tree;

	new = (splay_t *) malloc(sizeof(splay_t));
	if(new == NULL)
		return -1;

	new->key = key;
	new->data = data;
	if(t == null_node)
	{
		new->left = new->right = null_node;
		*tree = new;
		return 0;
	}

	t = splay(t, key, key_cmp);
	switch(key_cmp(t->key, key))
	{
		case -1: /* t->key < key */
			new->right = t->right;
			new->left = t;
			t->right = null_node;
			t = new;
			break;
		case  0: /* t->key == key */
			break;
		case  1: /* t->key > key */
			new->left = t->left;
			new->right = t;
			t->left = null_node;
			t = new;
			break;
	}

	*tree = t;
	return 0;
}

splay_t *splay_delete(splay_t **tree, void *key,
	int (*key_cmp)(void *, void *))
{
	splay_t *t, *ret;

	t = *tree;
	if(t == null_node)
		return NULL;

	t = splay(t, key, key_cmp);

	if(key_cmp(t->key, key) == 0)
	{
		ret = t;
		if(ret->left == null_node)
		{
			t = ret->right;
		}
		else
		{
			t = ret->left;
			t = splay(t, key, key_cmp);
			t->right = ret->right;
		}
		*tree = t;
		return ret;
	}
	return NULL;
}


int splay_by_addr(void *s1, void *s2)
{	
	if((int) s1 != (int) s2)
	{
		if((int) s1 < (int) s2)
			return -1;
		return 1;
	}
	return 0;
}


int splay_by_name(void *s1, void *s2)
{	
	int ret = 0;
	
	// use a hash of the string later 	
	ret = strncmp((char *)s2, (char *)s1, strlen(s1));

	if(ret != 0)
	{
		if(ret < 0)
			return -1;
		return 1;
	}	
	return 0;
}


