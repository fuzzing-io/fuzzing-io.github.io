#include <stdarg.h>
#include "dis.h"

void vlog(const char *fmt, ...)
{
	va_list args;

	va_start(args, fmt);
	vprintf(fmt, args);
	if(options.logfile)
		vfprintf(options.logfile, fmt, args);
	va_end(args);

	return;
}

