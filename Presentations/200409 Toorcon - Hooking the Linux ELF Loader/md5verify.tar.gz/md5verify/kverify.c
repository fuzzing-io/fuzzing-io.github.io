/*              
** md5verify kernel driver
** rjohnson@uninformed.org
**      
** This driver will perform md5 integrity verification on ELF 
** binaries by hooking the ELF loader's load_binary function. 
** The driver registers a character device which serves the 
** purpose of providing communication with the userland daemon
** in order to retrieve stored md5 digests from the database. 
**
** The device is set up to allow the userland daemon to poll
** the device until a database lookup is required. 
**
** Updated to suport SHA and LSM by Rodrigo Rubira Branco <rodrigo@kernelhacking.com>
*/
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/device.h>
#include <linux/sched.h>
#include <linux/smp_lock.h>
#include <linux/poll.h>
#include <linux/devfs_fs_kernel.h>
#include <asm/uaccess.h>
#include <linux/binfmts.h>
#include <linux/mount.h>
#include <linux/security.h>

#ifndef USE_SHA
 #include "md5.h"
#else
 #include "sha1.h"
#endif

// md5verify major device number
#define DEV_MAJOR 169
// if true, driver will stop execution of binaries failing integrity check
#define ALLOW_REJECTS 0

//#define TESTING
#undef  TESTING

int secondary=0;

#ifndef USE_SHA
int md5verify_sum (struct linux_binprm *linux_binprm);
#else
int sha1verify_sum (struct linux_binprm *linux_binprm);
#endif
int (*k_load_binary) (struct linux_binprm * bprm, struct pt_regs * regs);
struct linux_binfmt *_elf_format = NULL;

static spinlock_t md5verify_lock = SPIN_LOCK_UNLOCKED;
static wait_queue_head_t kern_wait_queue;
static spinlock_t dev_lock = SPIN_LOCK_UNLOCKED;
static wait_queue_head_t poll_wait_queue;

// dev_state has the following states
// closed      0
// open        1
// data ready  2
static int dev_state = 0;
static unsigned char fname[PATH_MAX + 6];

#ifndef USE_SHA
static unsigned char file_hash[16], md5sum[16];
#else
static unsigned char file_hash[20], md5sum[20];
#endif

static size_t fname_len = 0, fhash_len = 0;


int
#ifndef USE_LSM
_load_binary (struct linux_binprm *linux_binprm, struct pt_regs *regs)
#else
my_set_security (struct linux_binprm *linux_binprm)
#endif
{
  short device;
  int reject = 0;
  DECLARE_WAITQUEUE (wq, current);

  // pass execution through if the daemon isnt running
  if (dev_state == 0)
    #ifdef USE_LSM
	return 0;
    #else
        return k_load_binary (linux_binprm, regs);
    #endif

#ifdef TESTING
  printk ("[md5verify] exec: %s\n", linux_binprm->filename);
#endif
  spin_lock (&md5verify_lock);
  device =
    (MAJOR (linux_binprm->file->f_vfsmnt->mnt_sb->s_dev) * 256) +
    MINOR (linux_binprm->file->f_vfsmnt->mnt_sb->s_dev);
  memset (fname, 0, sizeof (fname));
  memcpy (fname, &device, 2);
  memcpy (fname + 2, &linux_binprm->file->f_dentry->d_inode->i_ino, 4);
  strncpy (&fname[6], linux_binprm->filename, sizeof (fname) - 1);
  fname_len = strlen (fname) + 1;
// wake up userspace
  dev_state++;
  spin_unlock (&md5verify_lock);

// sleep until a hash is received 
  add_wait_queue (&kern_wait_queue, &wq);
  set_current_state (TASK_INTERRUPTIBLE);
  schedule ();
  set_current_state (TASK_RUNNING);
  remove_wait_queue (&kern_wait_queue, &wq);

// do something
  #ifndef USE_SHA
  if (md5verify_sum (linux_binprm) < 0)
  #else
  if (sha1verify_sum (linux_binprm) < 0)
  #endif
  {
    printk ("[md5verify] error in md5sum calculation\n");
    goto cleanup;
  }
#ifdef TESTING
  if (fhash_len > 0)
  {
    printk ("[md5verify] stored hash:  %02x%02x%02x%02x%02x%02x%02x%02x",
	    file_hash[0], file_hash[1], file_hash[2], file_hash[3],
	    file_hash[4], file_hash[5], file_hash[6], file_hash[7]); 
    #ifndef USE_SHA
    printk ("%02x%02x%02x%02x%02x%02x%02x%02x\n", file_hash[8],
	    file_hash[9], file_hash[10], file_hash[11], file_hash[12],
	    file_hash[13], file_hash[14], file_hash[15]);
    #else
    printk ("%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x\n", file_hash[8],
	    file_hash[9], file_hash[10], file_hash[11], file_hash[12],
	    file_hash[13], file_hash[14], file_hash[15], file_hash[16],
	    file_hash[17], file_hash[18], file_hash[19]);
    #endif
  }
  printk ("[md5verify] verify hash:  %02x%02x%02x%02x%02x%02x%02x%02x",
	  md5sum[0], md5sum[1], md5sum[2], md5sum[3], md5sum[4],
	  md5sum[5], md5sum[6], md5sum[7]);
  #ifndef USE_SHA
  printk ("%02x%02x%02x%02x%02x%02x%02x%02x\n", md5sum[8], md5sum[9],
	  md5sum[10], md5sum[11], md5sum[12], md5sum[13], md5sum[14],
	  md5sum[15]);
  #else
  printk ("%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x\n", md5sum[8], md5sum[9],
	  md5sum[10], md5sum[11], md5sum[12], md5sum[13], md5sum[14],
	  md5sum[15], md5sum[16], md5sum[17], md5sum[18], md5sum[19]);
  #endif
#endif

  if (fhash_len < sizeof (md5sum)
      || memcmp (md5sum, file_hash, sizeof (md5sum)) != 0)
  {
    reject++;
  }
cleanup:
  spin_lock (&md5verify_lock);
  fhash_len = fname_len = 0;
  memset (fname, 0, sizeof (fname));
  memset (file_hash, 0, sizeof (file_hash));
  spin_unlock (&md5verify_lock);

  // warn and optionally fail execution if hash did not match
  if (reject)
  {
    printk ("[md5verify] Warning: %s failed integrity test\n",
	    linux_binprm->filename);
    if (ALLOW_REJECTS)
      return -EPERM;		// operation not permitted
  }
  #ifndef USE_LSM
  return k_load_binary (linux_binprm, regs);
  #else
  return 0;
  #endif
}

#ifdef USE_SHA
int
sha1verify_sum (struct linux_binprm *linux_binprm)
{
  ssize_t ret = 0;
  unsigned char *buf;
  int size;
  SHA1_CTX ctx;

  spin_lock (&md5verify_lock);
  size = linux_binprm->file->f_dentry->d_inode->i_size;
  memset (md5sum, 0, sizeof (md5sum));
  buf = kmalloc (size, GFP_KERNEL);

  if (buf == NULL)
  {
    printk ("[md5verify] Error: kmalloc failed\n");
    return -EFAULT;
  }

  ret = kernel_read (linux_binprm->file, 0, buf, size);

  if (ret < 0)
  {
    printk ("[md5verify] Error: kernel_read failed\n");
    spin_unlock (&md5verify_lock);
    goto cleanup;
  }

  spin_unlock (&md5verify_lock);
  SHA1Init (&ctx);
  SHA1Update (&ctx, buf, size);
  SHA1Final (md5sum, &ctx);

cleanup:
  kfree (buf);
  return ret;
}

#else // #ifdef USE_SHA

int
md5verify_sum (struct linux_binprm *linux_binprm)
{
  ssize_t ret = 0;
  char *buf;
  int size;
  md5_context *ctx;

  spin_lock (&md5verify_lock);
  ctx = kmalloc (sizeof (md5_context), GFP_KERNEL);
  size = linux_binprm->file->f_dentry->d_inode->i_size;
  memset (md5sum, 0, sizeof (md5sum));
  buf = kmalloc (size, GFP_KERNEL);

  if (buf <= 0)
  {
    printk ("[md5verify] Error: kmalloc failed\n");
    kfree (ctx);
    return -EFAULT;
  }
  ret = kernel_read (linux_binprm->file, 0, buf, size);

  if (ret < 0)
  {
    printk ("[md5verify] Error: kernel_read failed\n");
    spin_unlock (&md5verify_lock);
    goto cleanup;
  }

  spin_unlock (&md5verify_lock);
  md5_starts (ctx);
  md5_update (ctx, buf, size);
  md5_finish (ctx, md5sum);

cleanup:
  kfree (ctx);
  kfree (buf);
  return ret;
}
#endif


static ssize_t
md5dev_read (struct file *file, char __user * buf, size_t len, loff_t * ppos)
{
  ssize_t ret;
  ret = -EAGAIN;
  if (fname_len == 0)
    goto error;
  ret = -EFAULT;
  if (len < fname_len)
  {
    if (copy_to_user (buf, fname, len))
      goto error;
    return len;
  }
  if (copy_to_user (buf, fname, fname_len))
    goto error;
  return fname_len;
error:
  printk ("read: error\n");
  wake_up_interruptible (&kern_wait_queue);
  return ret;
}


static ssize_t
md5dev_write (struct file *file, const char __user * buf, size_t len,
	      loff_t * ppos)
{
  ssize_t ret;

// reset device state 
  dev_state--;
  ret = -EINVAL;
  if (len > sizeof (file_hash))
    goto cleanup;
  ret = -EFAULT;
  if (copy_from_user (file_hash, buf, len))
  {
    printk ("write: error\n");
    goto cleanup;
  }
  ret = fhash_len = len;
cleanup:
  wake_up_interruptible (&kern_wait_queue);
  return ret;
}


static unsigned int
md5dev_poll (struct file *file, poll_table * poll_tab)
{
  poll_wait (file, &poll_wait_queue, poll_tab);
  if (dev_state == 2)
    return (POLLIN | POLLRDNORM);
  else
    return 0;
}


static int
md5dev_open (struct inode *inode, struct file *file)
{
  int ret;

  printk ("open\n");
  spin_lock (&dev_lock);
  if (dev_state)
    ret = -EBUSY;
  else
  {
    ret = 0;
    dev_state++;
  }
  spin_unlock (&dev_lock);

  return ret;
}


static int
md5dev_close (struct inode *inode, struct file *file)
{
  printk ("close\n");
  spin_lock (&dev_lock);
  dev_state--;
  spin_unlock (&dev_lock);
  return 0;
}

#ifdef USE_LSM
static struct security_operations my_security_ops =
{
	.bprm_set_security	=	my_set_security,
};
#endif

static struct file_operations md5dev_fops = {
  .owner = THIS_MODULE,
  .read = md5dev_read,
  .write = md5dev_write,
  .poll = md5dev_poll,
  .open = md5dev_open,
  .release = md5dev_close,
};

static int __init
md5verify_init (void)
{

  #ifndef USE_LSM
  _elf_format = current->binfmt;
  k_load_binary = _elf_format->load_binary;
  _elf_format->load_binary = &_load_binary;
  #else

  if (register_security(&my_security_ops)) {
	printk("\n Failing registering the module with the kernel...\n");

	if ( mod_reg_security("md5verify", &my_security_ops)) {
		printk("\n Failure registering the module with the existing primary module...\n");
		return -EINVAL;
	}
	secondary=1;
  }
  #endif

  if (register_chrdev (DEV_MAJOR, "md5verify", &md5dev_fops))
  {
    printk ("[md5verify] unable to get major %d\n", DEV_MAJOR);
    return -EIO;
  }

  printk ("[md5verify] load_binary handler hooked\n");

  init_waitqueue_head (&poll_wait_queue);
  init_waitqueue_head (&kern_wait_queue);

  return 0;
}


static void __exit
md5verify_cleanup (void)
{
  printk ("[md5verify] load_binary handler restored\n");

  #ifdef USE_LSM
  if ( secondary )
  {
	if ( mod_unreg_security("md5verify", &my_security_ops))
		printk("\n Failure unregistering the module with the primary odule\n");
  }
  else
	if (unregister_security(&my_security_ops)) 
		printk("\n Failure unregistering the module with the kernel\n");
  #else
  	_elf_format->load_binary = k_load_binary;
  #endif

  unregister_chrdev (DEV_MAJOR, "md5verify");
  return;
}

module_init (md5verify_init);
module_exit (md5verify_cleanup);


MODULE_LICENSE("GPL");
