#include "dis.h"


struct disasm ia32 = {
	.arch = BINARY_ARCH_IA32,
	.disas_binary = dt_disas_x86_binary 
};

int disasm_init()
{

	if(register_disasm(&ia32) < 0)
		return -1;

	return 0;	
}

int register_disasm(struct disasm *new)
{
	struct disasm *ptr;

	if(!new)
		return -1;

	if(disasms == NULL)
	{
		disasms = new;
	}
	else
	{
		ptr = (struct disasm *)&disasms;
		while(ptr->next)
			ptr = ptr->next;

		ptr->next = new;
	}


	return 0;

}


int dt_disas_binary(binary_t *target)
{
	int fd;
	char *bin;

	struct disasm *disas;

	if(!disasms)
	{
		vlog("[dt_disas_binary] error: no registered disassemblers\n");
		return -1;
	}

	
	fd = open(target->name, O_RDONLY);
	if(fd < 0)
	{
		perror("[dt_disas_binary] could not open binary");
		return -1;
	}

	bin = mmap(NULL, target->size, PROT_READ, MAP_PRIVATE, fd, 0);
	if(!bin)
	{
		perror("[dt_disas_binary] could not map file");
		return -1;
	}

	target->insn_idx = splay_init();
	target->xref_idx = splay_init();
	target->func_idx = splay_init();
	target->name_idx = splay_init();
	target->xref_idx = splay_init();
	target->data_idx = splay_init();
	target->string_idx = splay_init();

	for(disas = disasms;
	    disas && disas->arch != target->arch;
	    disas = disas->next);

	if(!disas)
	{
		vlog("[dt_disas_binary] unsupported architecture\n");
		return -1;
	}
	disas->disas_binary(target, bin);
//	dt_disas_x86_binary(target, bin);

	return 0;
}



void dt_show_disassembly(binary_t *target)
{
	section_t * sect; 
	insn_t * insn;
	char *bin = NULL;
	int fd, i = 0;

	fd = open(target->name, O_RDONLY);
	if(!fd)
	{
		perror("[dt_show_disassembly] could not open binary");
		return;
	}
	
	bin = mmap(NULL, target->size, PROT_READ, MAP_PRIVATE, fd, 0);	
	
	sect = target->sections;
	while(sect != NULL && ++i)
	{
		vlog("\n;------------------------------------------------------------------------------\n");
		vlog("; Section %d  <%s>\n", i, sect->name);
		vlog("; virtual address: %08x  file offset:  %08x\n", sect->va, sect->offset);
		vlog("; section size:    %08x  ", sect->size);
		vlog("loadable:     %-3s\n", (sect->type & BINARY_SCN_TYPE_LOAD) ? "YES" : "NO");

		vlog("; section type:    ");
		if(sect->type & BINARY_SCN_TYPE_CODE)
			vlog("CODE ");
		if(sect->type & BINARY_SCN_TYPE_DATA)
			vlog("DATA ");

		vlog("     permissions:  ");
		if(sect->perm & PERM_READ)
    			vlog("READ ");
		if(sect->perm & PERM_WRITE)
			vlog("WRITE ");
		if(sect->perm & PERM_EXEC)
			vlog("EXECUTE ");

		vlog("\n;------------------------------------------------------------------------------\n");
		
		if(!sect->insns)
		    dt_hexdump(bin + sect->offset, sect->size, sect->va);

		insn = sect->insns;
		while(insn)
		{
			char str[256];
			xref_t *xref = NULL;
			name_t *name = NULL;

			
			if(!insn->name)
			    insn->name = splay_find(&target->name_idx, (void *)insn->va, splay_by_addr);

			if(insn->name != NULL)
			{
			    int i = -1; 
			    char buf[38];

			    vlog("\n%08x |\n", insn->va);
			    if(insn->name->type == DB_NAME_TYPE_SUB)
			    {
				vlog("........ |  ;;;;;;;;;;;;;;;;;;;;;;;;;;;\n"
				     "........ |  ;;; S U B R O U T I N E ;;;\n"
				     "........ |  ;;;;;;;;;;;;;;;;;;;;;;;;;;;\n");
			    }
			    
			    memset(buf, 0, sizeof(buf));
			    snprintf(buf, sizeof(buf) -1, "%s:", insn->name->data);
				vlog("........ |  %-38s  ", buf);

			    if(options.showbytes)
				vlog("%27s", "");


			    for(xref = target->xrefs; xref; xref = xref->next)
			    {
				if(xref->to == insn->va)
				{
				    if(i == -1)
				    {
					vlog(";  xrefs:  ");	
					i = 0;
				    }
				    vlog("0x%08x  ", xref->from);			
				    if(++i == 4)
				    {
					i = 0 ;
					if(options.showbytes)
					    vlog("\n........ |  %67s;%10s", "", "");
					else
					    vlog("\n........ |  %40s;%10s", "", "");
				    } 
				    
				    
				}				
			    }
			    vlog("\n........ "); 
			} 
			else
			{
			    vlog("\n%08x ", insn->va); 
			}



			if(options.showbytes)
 			{
				vlog("|  ");
				if (insn->bytes) {
					for (i = 0; i < insn->size; i++)
						vlog("%.2x ", insn->bytes[i]);
	
					vlog("  ");
					for (i = insn->size * 3; i < 22; i++)
						vlog(" ");
				}				
			}	
			
			name = NULL;
			if(insn->type == DB_INSN_TYPE_CALL)
				name = splay_find(&target->name_idx, (void *)strtoul(insn->dest, NULL, 16), splay_by_addr);
					
			if(name)
				snprintf(str, sizeof(str) -1, "  %-6s  <%s>", insn->mnemonic, name->data);		
			else
			{
				sprintf(str, "  %-6s  ", insn->mnemonic);			
				if(insn->atype)
				{
					strcat(str, insn->aux);
					if(insn->stype || insn->dtype)
					{
						strcat(str, ", ");
					}
				}
				if(insn->stype)
				{
					strncat(str, insn->src, sizeof(str) - strlen(str));
					if(insn->dtype)
					{
						strncat(str, ", ", sizeof(str) - strlen(str));
					}
				}
				if(insn->dtype)
				{
					strncat(str, insn->dest, sizeof(str) - strlen(str));
				}
			}
			vlog("|  %-36s    ;", str);			
			insn = insn->next;
		}
		putchar('\n');
		sect = sect->next;
		
	}
	
	return;
}


