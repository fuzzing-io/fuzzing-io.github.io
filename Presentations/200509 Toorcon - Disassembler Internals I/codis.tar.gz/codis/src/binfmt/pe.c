#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "dis.h"
#include "pe.h"

int dt_load_pe_symbols(binary_t *target, PEInfo *pe);
int dt_load_pe_sections(binary_t *target, PEInfo *pe);

unsigned long RVAtoOffset(binary_t *target, unsigned long rva);

unsigned long RVAtoOffset(binary_t *target, unsigned long rva) {
	section_t * section; 
	
	if(rva == 0)
		return 0;
	
	section = target->sections;
	while(section)
	{
		if((rva >= section->va) && (rva < section->va + section->size))
			return section->offset + rva - section->va;			
		section = section->next;	
	};
	
	return 0;
}

binary_t * dt_load_pe_binary(unsigned char *path)
{
	binary_t *target; 
	unsigned char *image;
	struct stat st;
	int fd;

	PEInfo PE;
	IMAGE_FILE_HEADER *PE_Phdr = NULL; /* PE Header */
	IMAGE_OPTIONAL_HEADER *PE_Ohdr = NULL; /* PE Optional Headers */
	
	if(stat(path, &st) < 0)
	{
		perror("[dt_load_pe_binary] could not stat file");
		return NULL;
	}

	if(st.st_size <= 0)
	{
		perror("[dt_load_pe_binary] supplied file size <= 0");
		return NULL;
	}
	
	fd = open(path, O_RDONLY);
	if(fd < 0)
	{
		perror("[dt_load_pe_binary] could not open binary");
		return NULL;
	}

	image = mmap(NULL, st.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
	if(!image)
	{
		if(options.verbose >= OUTPUT_VERBOSITY_DEBUG)
		    perror("[dt_load_pe_binary] could not map file");

		return NULL;
	}

	PE_Phdr = (IMAGE_FILE_HEADER *) image;
	if(image[0] == 'M' && image[1] == 'Z')
	{
		if(*(unsigned int *)(image + 0x3c) > st.st_size)
		{
			vlog("[dt_load_pe_binary] corrupt file header\n");
			return NULL;
		}
		PE_Phdr = (IMAGE_FILE_HEADER *) (image + *(unsigned int *)(image + 0x3c));  
	}

	if(*(char *)PE_Phdr == 'P' && *((char *)PE_Phdr + 1) == 'E')
	{
		PE_Phdr = (IMAGE_FILE_HEADER *)((char *)PE_Phdr + 4); 
	}
	else
	{
		if(options.verbose >= OUTPUT_VERBOSITY_DEBUG)
			vlog("[dt_load_pe_binary] file is not valid PE/COFF\n");
		return NULL;
	}
	
	if((PE_Phdr + sizeof(IMAGE_FILE_HEADER) + PE_Phdr->SizeOfOptionalHeader 
		+ (PE_Phdr->NumberOfSections * sizeof(IMAGE_SECTION_HEADER))))
	{
		vlog("[dt_load_pe_binary] corrupt PE header detected\n");
		return NULL;
	}
		
	target = calloc(1, sizeof(binary_t));
	if(!target)
		return NULL;

	if(options.verbose >= OUTPUT_VERBOSITY_DEBUG)
	    vlog("Parsing PE Header\n");

	target->type = BINARY_FORMAT_PE;
	strncpy(target->name, path, sizeof(target->name));
	target->size = st.st_size;

	PE_Ohdr = (IMAGE_OPTIONAL_HEADER *)((char *)PE_Phdr + sizeof(IMAGE_FILE_HEADER));
	target->entry = PE_Ohdr->AddressOfEntryPoint;
	target->entry_offset = 0; /* fill during section parsing */

	/* store register word size */
	if(PE_Phdr->Characteristics & IMAGE_FILE_MACHINE_I386)
	{
		target->wordsz = 32;
		target->arch   = BINARY_ARCH_IA32;
	}
	else
	{
		vlog("[dt_load_pe_binary] error: PE file not 32 bit\n");
		return NULL;
	}
	
	/* store endianess */
	if(PE_Phdr->Characteristics & IMAGE_FILE_BYTES_REVERSED_HI)
	{
		target->endian = BINARY_ENDIAN_BIG;
	}
	else if(PE_Phdr->Characteristics & IMAGE_FILE_BYTES_REVERSED_LO)
	{
		target->endian = BINARY_ENDIAN_LITTLE;
	}
	else
	{
		if(options.verbose >= OUTPUT_VERBOSITY_DEBUG)
			vlog("[dt_load_pe_binary] warning: Could not detect endianess. Defaulting to Little Endian\n");
		target->endian = BINARY_ENDIAN_LITTLE;
	}
	target->endian = BINARY_ENDIAN_LITTLE;


	PE.image = image;
	PE.PE_Phdr = PE_Phdr; 
	PE.PE_Ohdr = PE_Ohdr;
	
	if(dt_load_pe_sections(target, &PE) < 0)
	{
		vlog("[dt_load_pe_binary] error: could not load pe sections\n");
		return NULL;
	}
		
	target->sym_idx = splay_init();
	if(dt_load_pe_symbols(target, &PE) < 0)
		vlog("[dt_load_pe_binary] warning: could not load pe symbols\n");
		


	if(munmap(image, st.st_size) < 0)
	{
		perror("munmap");
		return NULL;
	}
	
	return target;

		
	
}

int dt_load_pe_sections(binary_t *target, PEInfo *pe)
{
	IMAGE_SECTION_HEADER *pShdr = NULL;
	section_t *sections = NULL;
	section_t *shdr_p = sections;
	int i;
	
	vlog("Loading Sections\n");

	pShdr = (IMAGE_SECTION_HEADER *)((int)(pe->PE_Ohdr) + (int)(pe->PE_Phdr->SizeOfOptionalHeader));
	if((pShdr->PointerToRawData > target->size)
	|| (pShdr->SizeOfRawData > target->size))
	{
		vlog("pointer to raw data\n");
		return -1;
	}
	
	for(i = 0; i < pe->PE_Phdr->NumberOfSections; i++)
	{
		section_t *shdr = calloc(sizeof(section_t), 1);

		shdr->va = pShdr->VirtualAddress;
		if(shdr->va < pe->PE_Ohdr->ImageBase)
			shdr->va += pe->PE_Ohdr->ImageBase;
			
		shdr->offset = pShdr->PointerToRawData;
		shdr->size = pShdr->SizeOfRawData;
		shdr->type = 0;
		
		if(!(pShdr->Characteristics & IMAGE_SCN_MEM_NOT_PAGED))
			shdr->type |= BINARY_SCN_TYPE_LOAD;

	if(pShdr->Characteristics & IMAGE_SCN_CNT_CODE)
	{
		shdr->type |= BINARY_SCN_TYPE_CODE;
	}
	else if((pShdr->Characteristics & IMAGE_SCN_CNT_INITIALIZED_DATA) ||
	(pShdr->Characteristics & IMAGE_SCN_CNT_UNINITIALIZED_DATA))
	{
		shdr->type |= BINARY_SCN_TYPE_DATA;
	}
	
	if(pShdr->Characteristics & IMAGE_SCN_MEM_READ)
		shdr->perm |= PERM_READ;
		
	if(pShdr->Characteristics & IMAGE_SCN_MEM_WRITE)		
		shdr->perm |= PERM_WRITE; 
		
	if(pShdr->Characteristics & IMAGE_SCN_MEM_EXECUTE)		
		shdr->perm |= PERM_EXEC; 
	

		shdr->name = pShdr->Name;
		if(shdr->name)
		{
			/* create local copy of pShdrion name */
			shdr->name = strdup(shdr->name);
		}
		shdr->next = NULL;

		if(shdr_p == NULL)
		{
			shdr->prev = NULL;
			shdr_p = sections = shdr;
		}
		else
		{
			shdr->prev = shdr_p;
			shdr_p->next = shdr;
			shdr_p = shdr_p->next;
		}
		pShdr++;
	}

	target->sections = sections;
	return 0;
}

int dt_load_pe_symbols(binary_t *target, PEInfo *pe)
{
	symbol_t *symbols = NULL;
	symbol_t *sym_p = symbols; 

	
	IMAGE_IMPORT_DESCRIPTOR *pImportDesc;
	IMAGE_THUNK_DATA *pThunk;
	IMAGE_IMPORT_BY_NAME *pImportName;

	pImportDesc = (void *)((int)pe->image + RVAtoOffset(target, (pe->PE_Ohdr->DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].VirtualAddress + pe->PE_Ohdr->ImageBase)));
	
	if(pImportDesc == (void *)pe->image)
	{
			vlog("[dt_load_pe_symbols] warning: import table was not found\n");
			return 0;
	}	

	while (pImportDesc->Name) // DLL Name
	{
		unsigned long *pThunkRva = (unsigned long *)pImportDesc->FirstThunk;
		char *pszModName = pe->image + RVAtoOffset(target, pImportDesc->Name + pe->PE_Ohdr->ImageBase);
		if(options.verbose >= OUTPUT_VERBOSITY_DEBUG)		 
			vlog("Reqired DLL: %s\n", pszModName);

		pThunk = (void *)pe->image + RVAtoOffset(target, pImportDesc->OriginalFirstThunk + pe->PE_Ohdr->ImageBase);		
		for (; pThunk->u1.AddressOfData; pThunk++, pThunkRva++) // loop imported functions
		{
			symbol_t *symbol = calloc(1, sizeof(symbol_t));

			pImportName = pThunk->u1.AddressOfData;
			if(options.verbose >= OUTPUT_VERBOSITY_DEBUG)
				vlog("%08x %s\n", pThunkRva, pe->image + RVAtoOffset(target, (unsigned int)pImportName->Name + pe->PE_Ohdr->ImageBase));
			
			symbol->va = (unsigned int)pThunkRva + pe->PE_Ohdr->ImageBase;
			symbol->offset = RVAtoOffset(target, (unsigned int)pThunkRva);			
			symbol->type = BINARY_SYM_TYPE_CODE;
			symbol->name = strdup(pe->image + RVAtoOffset(target, (unsigned int)pImportName->Name + pe->PE_Ohdr->ImageBase));
			
			if(sym_p == NULL)
			{
				symbol->prev = NULL;
				sym_p = symbols = symbol;
			}
			else
			{
				symbol->prev = sym_p;
				sym_p->next = symbol;
				sym_p = sym_p->next;
			}
			splay_insert(&target->sym_idx, (void *)symbol->va, symbol, splay_by_addr);
		}
		pImportDesc++;  // advance to next imported module descriptor
	}
	
	target->symbols = symbols;
	return 0;
}




