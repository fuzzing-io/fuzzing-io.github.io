#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/mman.h>
//#include <elf.h>

#include "lists.h"
#include "libdasm.h"

#define MAXSTR 1024

#define BINARY_FORMAT_UNDEF	0
#define BINARY_FORMAT_ELF	1
#define BINARY_FORMAT_PE	2
#define BINARY_FORMAT_NUM	2	// number of supported binary formats

#define BINARY_ARCH_UNDEF	0
#define BINARY_ARCH_IA32	1
#define BINARY_ARCH_NUM		1

#define BINARY_TYPE_UNDEF	0
#define BINARY_TYPE_EXEC	1
#define BINARY_TYPE_DYN		2

#define BINARY_ENDIAN_LITTLE	1
#define BINARY_ENDIAN_BIG	2

#define BINARY_BITS_32		32
#define BINARY_BITS_64		64

#define BINARY_SCN_TYPE_CODE	1
#define BINARY_SCN_TYPE_DATA	2
#define BINARY_SCN_TYPE_LOAD	4

#define BINARY_SYM_TYPE_CODE	1
#define BINARY_SYM_TYPE_DATA	2

#define OUTPUT_VERBOSITY_NORMAL	1
#define OUTPUT_VERBOSITY_VERBOSE	2
#define OUTPUT_VERBOSITY_DEBUG	99

#define PERM_READ			4
#define PERM_WRITE			2
#define PERM_EXEC			1

#define DB_NAME_TYPE_DATA	1
#define DB_NAME_TYPE_SUB		2
#define DB_NAME_TYPE_LOC		3
#define DB_NAME_TYPE_OFFSET	4
#define DB_NAME_TYPE_INT		5

#define DB_INSN_TYPE_CALL	1
#define DB_INSN_TYPE_JMP		2
#define DB_INSN_TYPE_ARITH	3
#define DB_INSN_TYPE_MOV		4


struct options {
	uint8_t verbose;
	uint8_t showbytes;
	uint8_t showsyms;
	uint8_t showstrings; 
	uint8_t asm_fmt;
	uint8_t headers;
	FILE *logfile;
};
struct options options;



typedef struct _binary {
	struct _binary *prev, *next;
	int arch;
	uint8_t  type;			// binary type 
	uint8_t  wordsz;		// word size   
	uint8_t  endian;		// endianess  
	uint8_t  name[MAXSTR];		// binary path
	uint32_t entry;			// entry point VA
	uint32_t entry_offset;		// entry point offset
	uint32_t size;			// file size
	struct _section *sections;	
	struct _symbol *symbols;	
	struct _func *functions;	
	struct _name *names;	    	
	struct _data *data;		
	struct _xref *xrefs;		
	struct _string *strings;	
					
	splay_t * insn_idx;		
	splay_t * sym_idx;		
	splay_t * func_idx;		
	splay_t * name_idx;		
	splay_t * data_idx;		
	splay_t * xref_idx;		
	splay_t * string_idx;		
} binary_t;

typedef struct _section {
	struct _section *prev, *next;
	uint8_t * name;			// section name	
	uint32_t va;			// section VA
	uint32_t offset;		// offset
	uint32_t size;			// size
	uint8_t type;			// Section type [CODE, DATA]
	uint8_t perm;			// section perms [rwx]
	struct _insn * insns;		// disassembly of section
} section_t;

typedef struct _symbol {
	struct _symbol *prev, *next;
	uint32_t va;			// virtual address
	uint32_t offset;		// offset
	uint32_t size;			// function size
	uint32_t type;			// symbol type
	uint8_t  *name;			// symbol name
} symbol_t;

typedef struct _insn {
	struct _insn *prev, *next;
	uint32_t va;			// virtual address
	uint32_t offset;		// offset
	uint32_t size;			// number of bytes in insn 
	uint8_t bytes[16];	// instruction bytes
	uint8_t mnemonic[16];		// mnemonic
	uint32_t type;			// type of insn   // FIXME -- not really used yet
	uint8_t src[20];		// src operand
	uint32_t stype;			// src operand type
	uint16_t s_perm;		// src operand perms
	uint8_t dest[20];		// dst operand
	uint32_t dtype;			// dst operand type
	uint16_t d_perm;		// dst operand perms
	uint8_t aux[20];		// aux operand
	uint32_t atype;			// aux operand type
	uint16_t a_perm;		// aux operand perms
	struct _name *name;		// address name
} insn_t;


typedef struct _name {
	struct _name *prev, *next;
	uint32_t va;			// virtual address
	uint32_t type;			// [data, sub, loc, offset, int]
	uint8_t  * data;		// symbolic name
} name_t;



typedef struct _func {
	struct _func *prev, *next;
	uint32_t va;			// virtual address
	uint32_t offset;		// offset
	struct _name *name;		
} func_t;

typedef struct _xref {
	struct _xref *prev, *next;
	uint32_t   from;		// referencing addr
	uint32_t   to;			// referenced addr
	uint16_t  perm;		// [rwx]
} xref_t;

typedef struct _string {
	struct _string *prev, *next;
	uint32_t va;			// virtual address
	uint32_t offset;		// offset
	uint8_t *data;			// string
} string_t;


struct binfmt {
	struct binfmt * next;
	int binfmt; 
	binary_t (*load_binary)(unsigned char *path);
};
struct binfmt *binfmts;

struct disasm {
	struct disasm * next;
	int arch;
	int (*disas_binary)(binary_t *target, unsigned char *bin);
};
struct disasm *disasms;

int binfmt_init();
int register_binfmt(struct binfmt *new);

binary_t * dt_load_binary(unsigned char *path);
binary_t * dt_load_elf_binary(unsigned char *path);
binary_t * dt_load_pe_binary(unsigned char *path);
int dt_show_file_header(binary_t *target);
void dt_show_symbols(binary_t *target);

int disasm_init();
int register_disasm(struct disasm *new);
int dt_disas_binary(binary_t *target);
int dt_disas_x86_binary(binary_t *target, unsigned char *bin);
void dt_show_disassembly(binary_t *target);

void vlog(const char *fmt, ...);
int dt_hexdump(unsigned char *buf, int len, unsigned long va);

